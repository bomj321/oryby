 <?php
require 'Connect.php'; 
error_reporting(0);
?>
 <div class="navbar yamm navbar-default">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" data-toggle="collapse" data-target="#navbar-collapse-3" class="navbar-toggle">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a href="javascript:void(0);" class="navbar-brand visible-xs">
                        <img src="img/logo.png" alt="logo">
                    </a>
                </div>
                <div id="navbar-collapse-3" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <!-- Home -->
                        <li class="dropdown active"><a href="index.php">Home</a> </li>
                           
                        <!-- end li dropdown -->    
                        <!-- Features -->
                        <li class="dropdown left"><a href="buy.php">Buyers</a>
                            <!-- end ul dropdown-menu -->
                        </li><!-- end li dropdown -->
                        <!-- Pages -->
                        <li class="dropdown yamm-fw"><a href="suppliers.php" >Suppliers</a>
                           
                        </li><!-- end li dropdown -->
                        <!-- elements -->
                  <!--    <li><a href="elements.html">Elements</a></li>   -->
                       
                   <!-- end dropdown -->
						
                    </ul><!-- end navbar-nav -->
                    <ul class="nav navbar-nav navbar-right">
                        <li class="dropdown right">
                            <a href="#" data-toggle="dropdown" class="dropdown-toggle">
                                <span class="hidden-sm">Categories</span><i class="fa fa-bars ml-5"></i>
                            </a>
                            <ul class="dropdown-menu">
							
							<?php 
							$sql="Select * from `categories`";
							$result=mysqli_query($connection,$sql);
							while($row=mysqli_fetch_array($result)){
								
								$title=$row['title'];
								$pcat=$row['pcategory'];
								$sql2="select * from `categories` where `pcategory`='$title'";
								$result2=mysqli_query($connection,$sql2);
								
								
								?>
							
                   <li><a href="javascript:void(0);"><?php echo $title; ?></a> </li>
															  <?php } ?>
							 <!--   
								/*  $numofrows=mysqli_num_rows($result2);
								  if($numofrows>0){
								  while($row2=mysqli_fetch_array($result2)){
								  ?>   

								  <ul class="dropdown-menu">
                                        <li><a href="category.html"><?php //echo $row2['title']; ?></a></li>
                                        
                                    </ul>

								  */
                               
								
							//		
                           <!--     <li class="dropdown-submenu"><a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown">Womens</a>
                                    <ul class="dropdown-menu">
                                        <li><a href="category.html">Bresses</a></li>
                                        <li><a href="category.html">T-shirts</a></li>
                                        <li><a href="category.html">Skirts</a></li>
                                        <li><a href="category.html">Jeans</a></li>
                                        <li><a href="category.html">Pullover</a></li>
                                    </ul>
                                </li>
                                <li><a href="javascript:void(0);">Kids</a></li>
                                <li><a href="javascript:void(0);">Fashion</a></li>
                                <li class="dropdown-submenu"><a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown">SportWear</a>
                                    <ul class="dropdown-menu">
                                        <li><a href="category.html">Shoes</a></li>
                                        <li><a href="category.html">Bags</a></li>
                                        <li><a href="category.html">Pants</a></li>
                                        <li><a href="category.html">SwimWear</a></li>
                                        <li><a href="category.html">Bicycles</a></li>
                                    </ul>
                                </li>
                                <li><a href="javascript:void(0);">Bags</a></li>
                                <li><a href="javascript:void(0);">Shoes</a></li>
                                <li><a href="javascript:void(0);">HouseHolds</a></li>
                                <li class="dropdown-submenu"><a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown">Technology</a>
                                    <ul class="dropdown-menu">
                                        <li><a href="category.html">TV</a></li>
                                        <li><a href="category.html">Camera</a></li>
                                        <li><a href="category.html">Speakers</a></li>
                                        <li><a href="category.html">Mobile</a></li>
                                        <li><a href="category.html">PC</a></li>
                                    </ul>
                                </li>  -->
                            </ul><!-- end ul dropdown-menu -->
                        </li><!-- end dropdown -->
                    </ul><!-- end navbar-right -->
                </div><!-- end navbar collapse -->
            </div><!-- end container -->
        </div>