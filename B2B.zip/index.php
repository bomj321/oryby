<?php
require 'Connect.php'; 
error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Plus - E-Commerce Template</title>
    <meta charset="utf-8">
    <meta name="description" content="Plus E-Commerce Template">
    <meta name="author" content="Diamant Gjota" />
    <meta name="keywords" content="plus, html5, css3, template, ecommerce, e-commerce, bootstrap, responsive, creative" />
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;">

    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
	
    <!--Favicon-->
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
    <link rel="icon" href="img/favicon.ico" type="image/x-icon">
    
    <!-- css files -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.min.css" />
    <link rel="stylesheet" type="text/css" href="css/owl.theme.default.min.css" />
    <link rel="stylesheet" type="text/css" href="css/animate.css" />
    <link rel="stylesheet" type="text/css" href="css/swiper.css" />
    
    <!-- this is default skin you can replace that with: dark.css, yellow.css, red.css ect -->
    <link id="pagestyle" rel="stylesheet" type="text/css" href="css/default.css" />
    
    <!-- Google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,700,700i,900,900i&subset=cyrillic,cyrillic-ext,latin-ext" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:100,300,400,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Dosis:200,300,400,500,600,700,800&amp;subset=latin-ext" rel="stylesheet">
    
</head>
    <body>
        
        <!-- start topBar -->
<?php require 'topbar.php' ?>
        <!-- end topBar -->
        
        <div class="middleBar">
            <div class="container">
                <div class="row display-table">
                    <div class="col-sm-3 vertical-align text-left hidden-xs">
                        <a href="javascript:void(0);">
                            <img width="160" src="img/logo-big.png" alt="" />
                        </a>
                    </div><!-- end col -->
                    <div class="col-sm-7 vertical-align text-center">
                        <form>
                            <div class="row grid-space-1">
                                <div class="col-sm-6">
                                    <input type="text" name="keyword" class="form-control input-lg" placeholder="Search">
                                </div><!-- end col -->
                                <div class="col-sm-3">
                                    <select class="form-control input-lg" name="category">
                                        <option value="all">All Categories</option>
                                        <optgroup label="Mens">
                                            <option value="shirts">Shirts</option>
                                            <option value="coats-jackets">Coats & Jackets</option>
                                            <option value="underwear">Underwear</option>
                                            <option value="sunglasses">Sunglasses</option>
                                            <option value="socks">Socks</option>
                                            <option value="belts">Belts</option>
                                        </optgroup>
                                        <optgroup label="Womens">
                                            <option value="bresses">Bresses</option>
                                            <option value="t-shirts">T-shirts</option>
                                            <option value="skirts">Skirts</option>
                                            <option value="jeans">Jeans</option>
                                            <option value="pullover">Pullover</option>
                                        </optgroup>
                                        <option value="kids">Kids</option>
                                        <option value="fashion">Fashion</option>
                                        <optgroup label="Sportwear">
                                            <option value="shoes">Shoes</option>
                                            <option value="bags">Bags</option>
                                            <option value="pants">Pants</option>
                                            <option value="swimwear">Swimwear</option>
                                            <option value="bicycles">Bicycles</option>
                                        </optgroup>
                                        <option value="bags">Bags</option>
                                        <option value="shoes">Shoes</option>
                                        <option value="hoseholds">HoseHolds</option>
                                        <optgroup label="Technology">
                                            <option value="tv">TV</option>
                                            <option value="camera">Camera</option>
                                            <option value="speakers">Speakers</option>
                                            <option value="mobile">Mobile</option>
                                            <option value="pc">PC</option>
                                        </optgroup>
                                    </select>
                                </div><!-- end col -->
                                <div class="col-sm-3">
                                    <input type="submit"  class="btn btn-default btn-block btn-lg" value="Search">
                                </div><!-- end col -->
                            </div><!-- end row -->
                        </form>
                    </div><!-- end col -->
                    <div class="col-sm-2 vertical-align header-items hidden-xs">
                        <div class="header-item mr-5">
                            <a href="javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Wishlist">
                                <i class="fa fa-heart-o"></i>
                                <sub>32</sub>
                            </a>
                        </div>
                        <div class="header-item">
                            <a href="javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Compare">
                                <i class="fa fa-refresh"></i>
                                <sub>2</sub>
                            </a>
                        </div>
                    </div><!-- end col -->
                </div><!-- end  row -->
            </div><!-- end container -->
        </div><!-- end middleBar -->
        
        <!-- start navbar -->
	<?php require 'navh.php'; ?>	
       <!-- end navbar -->
        
        <!-- start section -->
        <section class="section light-backgorund">
            <div class="container">
                <div id="carousel-example-generic" class="carousel home-slide" data-interval="false" data-ride="carousel">
                    <!-- Indicators -->
                    <ol class="carousel-indicators">
                        <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                        <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                    </ol>

                    <!-- Wrapper for slides -->
                    <div class="carousel-inner" role="listbox">
                        <div class="item active" style="background-image: url(img/slider/slider_11.jpg)">
                            <div class="item-inner">
                                <div class="carousel-caption">
                                    <h3 class="text-white">New Collection in Clothing for Women</h3>
                                    <p class="lead">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                    <h5 class="text-white">Starts From <span class="text-primary">$49.90</span></h5>
                                    
                                    <hr class="spacer-10 no-border"/>
                                    
                                    <a href="javascript:void(0);" class="btn btn-default semi-circle">See Collection</a>
                                </div><!-- end carousel-caption -->
                            </div><!-- end item-inner -->
                        </div><!-- end item -->
                        <div class="item" style="background-image: url(img/slider/slider_12.jpg)">
                            <div class="item-inner">
                                <div class="carousel-caption">
                                    <h3 class="text-white">New macbook pro</h3>
                                    <p class="lead">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                    <h5 class="text-white">Starts From <span class="text-primary">$1449.00</span></h5>
                                    
                                    <hr class="spacer-10 no-border"/>
                                    
                                    <a href="javascript:void(0);" class="btn btn-default semi-circle">Buy Now</a>
                                </div><!-- end carousel-caption -->
                            </div><!-- end item-inner -->
                        </div><!-- end item -->
                    </div><!-- end carousel-inner -->
                    <!-- Controls -->
                    <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
                        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div><!-- end carousel -->
            </div><!-- end container -->
        </section>
        <!-- end section -->
        
        <!-- start section -->
        <section class="light-backgorund">
            <div class="container">
			 <div class="row">
        
        <div class="col-lg-6 mb-6">
          <div class="card h-100">
            <h4 class="card-header">ECO Friendly products </h4>
            <div class="card-body">
              <p class="card-text" style="text-align:justify;">It is our ambition to provide the easiest and most accessible way to buy bitcoins without compromising on safety.
</p>
            </div>
            <div class="card-footer">
              <a href="#" class="btn btn-primary">ALL ECO's </a>
            </div>
          </div>
        </div>
        <div class="col-lg-6 mb-6">
          <div class="card h-100">
            <h4 class="card-header">Innovation products </h4>
            <div class="card-body">
              <p class="card-text" style="text-align:justify;">It is our ambition to provide the easiest and most accessible way to buy 
			  bitcoins without compromising on safety.
			  </p>
            </div>
            <div class="card-footer">
              <a href="#" class="btn btn-primary">Innovation</a>
            </div>
          </div>
        </div>
      </div>
			
		<br>  <br>	
			
			
                <div class="content primary-background">
                    <div class="row">
					<?php		   $query ="SELECT * FROM products";
               $result=mysqli_query($connection,$query);
			   ?>
                        <div class="col-sm-12">
                            <div class="title-header">


			    
                               <h5 class="title text-white">ShowCase Products </h5>
                            </div><!-- end title-header -->
                        </div><!-- end col -->
                    </div><!-- end row -->
                    <?php
                  while( $row=mysqli_fetch_array($result)){ ?>
         <div class="col-sm-6 col-md-3">
                        
                            <div class="cat-item-style2">
                                <figure>
                                    <a href="category.html">
                                      <!--  <img src="img/products/men_03.jpg" alt=""   -->
										 <img src="images/<?php echo $row['image']; ?>" alt="" />
										
                                    </a>
                                </figure>
                                <div class="title">
                                    <h6><a href="category.html"><?php echo $row['ntitle']; ?></a></h6>
                                </div><!-- end title -->
                            </div><!-- end cat-item-style2 -->
                        <!-- end col -->
                   
                   <!-- end row -->
				  
				   </div>
				   <?php  } ?>
                    <div class="row">
                        <div class="col-sm-12 text-center">
                            <a href="category.html"><h5>All Categories</h5></a>
                        </div><!-- end col -->
                    </div><!-- end row -->
                </div><!-- end content -->
            </div><!-- end container -->
        </section>
        <!-- end section -->
        
        <!-- start section -->
        <section class="light-backgorund">
            <div class="container">
                <div class="content white-background">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="title-header">
                                <div class="row display-table">
                                    <div class="col-sm-8 vertical-align">
                                        <h5 class="title"><a href="category.html">Mens Popular</a></h5>
                                    </div><!-- end col -->
                                    <div class="col-sm-4 vertical-align">
                                        <div class="filter">
                                            <form class="form-horizontal">
                                                <div class="form-group">
                                                    <label for="men-filter-cat" class="col-sm-4 control-label">Filter</label>
                                                    <div class="col-sm-8">
                                                        <select id="men-filter-cat" class="form-control" name="men-filter-cat">
                                                            <option value="all">All Categories</option>
                                                            <option value="shirts">Shirts</option>
                                                            <option value="coats-jackets">Coats & Jackets</option>
                                                            <option value="underwear">Underwear</option>
                                                            <option value="sunglasses">Sunglasses</option>
                                                            <option value="socks">Socks</option>
                                                            <option value="belts">Belts</option>
                                                        </select>
                                                    </div><!-- end col -->
                                                </div><!-- end form-group -->
                                            </form>
                                        </div><!-- end filter -->
                                    </div><!-- end col -->
                                </div><!-- end row -->
                            </div><!-- end title-header -->
                        </div><!-- end col -->
                    </div><!-- end row -->
                    
                    <div class="row column-4">
                        <div class="col-sm-6 col-md-3">
                            <div class="thumbnail store style2">
                                <div class="header">
                                    <div class="badges">
                                        <span class="product-badge top left white-backgorund text-primary semi-circle">Popular</span>
                                        <span class="product-badge top right text-warning">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star-half-o"></i>
                                        </span>
                                    </div>
                                    <figure>
                                        <a href="javascript:void(0);">
                                            <img class="front" src="img/products/men_01.jpg" alt="">
                                            <img class="back" src="img/products/men_02.jpg" alt="">
                                        </a>
                                    </figure>
                                    <div class="icons">
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-heart-o"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-gift"></i></a>
                                        <a class="icon" href="javascript:void(0);" data-toggle="modal" data-target=".productQuickView"><i class="fa fa-search"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-cart-plus mr-5"></i>Add to cart</a>
                                    </div>
                                </div>
                                <div class="caption">
                                    <h6 class="regular"><a href="shop-single-product-v1.html">Lorem Ipsum dolor sit</a></h6>
                                    <div class="price">
                                        <small class="amount off">$68.99</small>
                                        <span class="amount text-primary">$59.99</span>
                                    </div>
                                </div><!-- end caption -->
                            </div><!-- end thumbnail -->
                        </div><!-- end col -->
                        <div class="col-sm-6 col-md-3">
                            <div class="thumbnail store style2">
                                <div class="header">
                                    <div class="badges">
                                        <span class="product-badge top left text-warning">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star-half-o"></i>
                                        </span>
                                    </div>
                                    <figure>
                                        <a href="javascript:void(0);">
                                            <img src="img/products/men_03.jpg" alt="">
                                        </a>
                                    </figure>
                                    <div class="icons">
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-heart-o"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-gift"></i></a>
                                        <a class="icon" href="javascript:void(0);" data-toggle="modal" data-target=".productQuickView"><i class="fa fa-search"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-cart-plus mr-5"></i>Add to cart</a>
                                    </div>
                                </div>
                                <div class="caption">
                                    <h6 class="regular"><a href="shop-single-product-v1.html">Lorem Ipsum dolor sit</a></h6>
                                    <div class="price">
                                        <small class="amount off">$68.99</small>
                                        <span class="amount text-primary">$59.99</span>
                                    </div>
                                </div><!-- end caption -->
                            </div><!-- end thumbnail -->
                        </div><!-- end col -->
                        <div class="col-sm-6 col-md-3">
                            <div class="thumbnail store style2">
                                <div class="header">
                                    <div class="badges">
                                        <span class="product-badge top right white-backgorund text-warning semi-circle">Out of stock</span>
                                    </div>
                                    <figure class="layer">
                                        <a href="javascript:void(0);">
                                            <img src="img/products/men_04.jpg" alt="">
                                        </a>
                                    </figure>
                                    <div class="icons">
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-heart-o"></i></a>
                                        <a class="icon" href="javascript:void(0);" data-toggle="modal" data-target=".productQuickView"><i class="fa fa-search"></i></a>
                                    </div>
                                </div>
                                <div class="caption">
                                    <h6 class="regular"><a href="shop-single-product-v1.html">Lorem Ipsum dolor sit</a></h6>
                                    <div class="price">
                                        <small class="amount off">$68.99</small>
                                        <span class="amount text-primary">$59.99</span>
                                    </div>
                                </div><!-- end caption -->
                            </div><!-- end thumbnail -->
                        </div><!-- end col -->
                        <div class="col-sm-6 col-md-3">
                            <div class="thumbnail store style2">
                                <div class="header">
                                    <div class="badges">
                                        <span class="product-badge top right info-background text-white semi-circle">-30%</span>
                                        <span class="product-badge top left white-backgorund text-danger semi-circle">Sale</span>
                                    </div>
                                    <figure>
                                        <a href="javascript:void(0);">
                                            <img src="img/products/men_05.jpg" alt="">
                                        </a>
                                    </figure>
                                    <div class="icons">
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-heart-o"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-gift"></i></a>
                                        <a class="icon" href="javascript:void(0);" data-toggle="modal" data-target=".productQuickView"><i class="fa fa-search"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-cart-plus mr-5"></i>Add to cart</a>
                                    </div>
                                </div>
                                <div class="caption">
                                    <h6 class="regular"><a href="shop-single-product-v1.html">Lorem Ipsum dolor sit</a></h6>
                                    <div class="price">
                                        <small class="amount off">$68.99</small>
                                        <span class="amount text-primary">$59.99</span>
                                    </div>
                                </div><!-- end caption -->
                            </div><!-- end thumbnail -->
                        </div><!-- end col -->
                        <div class="col-sm-6 col-md-3">
                            <div class="thumbnail store style2">
                                <div class="header">
                                    <figure>
                                        <a href="javascript:void(0);">
                                            <img src="img/products/men_06.jpg" alt="">
                                        </a>
                                    </figure>
                                    <div class="icons">
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-heart-o"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-gift"></i></a>
                                        <a class="icon" href="javascript:void(0);" data-toggle="modal" data-target=".productQuickView"><i class="fa fa-search"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-cart-plus mr-5"></i>Add to cart</a>
                                    </div>
                                </div>
                                <div class="caption">
                                    <h6 class="regular"><a href="shop-single-product-v1.html">Lorem Ipsum dolor sit</a></h6>
                                    <div class="price">
                                        <small class="amount off">$68.99</small>
                                        <span class="amount text-primary">$59.99</span>
                                    </div>
                                </div><!-- end caption -->
                            </div><!-- end thumbnail -->
                        </div><!-- end col -->
                        <div class="col-sm-6 col-md-3">
                            <div class="thumbnail store style2">
                                <div class="header">
                                    <figure>
                                        <a href="javascript:void(0);">
                                            <img src="img/products/men_07.jpg" alt="">
                                        </a>
                                    </figure>
                                    <div class="icons">
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-heart-o"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-gift"></i></a>
                                        <a class="icon" href="javascript:void(0);" data-toggle="modal" data-target=".productQuickView"><i class="fa fa-search"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-cart-plus mr-5"></i>Add to cart</a>
                                    </div>
                                </div>
                                <div class="caption">
                                    <h6 class="regular"><a href="shop-single-product-v1.html">Lorem Ipsum dolor sit</a></h6>
                                    <div class="price">
                                        <small class="amount off">$68.99</small>
                                        <span class="amount text-primary">$59.99</span>
                                    </div>
                                </div><!-- end caption -->
                            </div><!-- end thumbnail -->
                        </div><!-- end col -->
                        <div class="col-sm-6 col-md-3">
                            <div class="thumbnail store style2">
                                <div class="header">
                                    <figure>
                                        <a href="javascript:void(0);">
                                            <img src="img/products/men_08.jpg" alt="">
                                        </a>
                                    </figure>
                                    <div class="icons">
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-heart-o"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-gift"></i></a>
                                        <a class="icon" href="javascript:void(0);" data-toggle="modal" data-target=".productQuickView"><i class="fa fa-search"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-cart-plus mr-5"></i>Add to cart</a>
                                    </div>
                                </div>
                                <div class="caption">
                                    <h6 class="regular"><a href="shop-single-product-v1.html">Lorem Ipsum dolor sit</a></h6>
                                    <div class="price">
                                        <small class="amount off">$68.99</small>
                                        <span class="amount text-primary">$59.99</span>
                                    </div>
                                </div><!-- end caption -->
                            </div><!-- end thumbnail -->
                        </div><!-- end col -->
                        <div class="col-sm-6 col-md-3">
                            <div class="thumbnail store style2">
                                <div class="header">
                                    <figure>
                                        <a href="javascript:void(0);">
                                            <img src="img/products/bags_06.jpg" alt="">
                                        </a>
                                    </figure>
                                    <div class="icons">
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-heart-o"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-gift"></i></a>
                                        <a class="icon" href="javascript:void(0);" data-toggle="modal" data-target=".productQuickView"><i class="fa fa-search"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-cart-plus mr-5"></i>Add to cart</a>
                                    </div>
                                </div>
                                <div class="caption">
                                    <h6 class="regular"><a href="shop-single-product-v1.html">Lorem Ipsum dolor sit</a></h6>
                                    <div class="price">
                                        <small class="amount off">$68.99</small>
                                        <span class="amount text-primary">$59.99</span>
                                    </div>
                                </div><!-- end caption -->
                            </div><!-- end thumbnail -->
                        </div><!-- end col -->
                    </div><!-- end row -->
                    
                    <hr class="spacer-10 no-border"/>
                    
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="title-header">
                                <h6 class="title">Brands</h6>
                            </div><!-- end title-header -->
                        </div><!-- end col -->
                    </div><!-- end row -->
                    
                    <div id="owl-demo" class="owl-carousel column-5 owl-theme">
                        <div class="item">
                            <figure class="zoom-out">
                                <img src="img/brands/brand_01.jpg" alt="">
                            </figure>
                        </div><!-- end item -->
                        <div class="item">
                            <figure class="zoom-out">
                                <img src="img/brands/brand_02.jpg" alt="">
                            </figure>
                        </div><!-- end item -->
                        <div class="item">
                            <figure class="zoom-out">
                                <img src="img/brands/brand_03.jpg" alt="">
                            </figure>
                        </div><!-- end item -->
                        <div class="item">
                            <figure class="zoom-out">
                                <img src="img/brands/brand_04.jpg" alt="">
                            </figure>
                        </div><!-- end item -->
                        <div class="item">
                            <figure class="zoom-out">
                                <img src="img/brands/brand_01.jpg" alt="">
                            </figure>
                        </div><!-- end item -->
                        <div class="item">
                            <figure class="zoom-out">
                                <img src="img/brands/brand_02.jpg" alt="">
                            </figure>
                        </div><!-- end item -->
                        <div class="item">
                            <figure class="zoom-out">
                                <img src="img/brands/brand_03.jpg" alt="">
                            </figure>
                        </div><!-- end item -->
                        <div class="item">
                            <figure class="zoom-out">
                                <img src="img/brands/brand_04.jpg" alt="">
                            </figure>
                        </div><!-- end item -->
                    </div><!-- end owl carousel -->
                </div><!-- end content -->
            </div><!-- end container -->
        </section>
        <!-- end section -->
        
        <!-- start section -->
        <section class="light-backgorund">
            <div class="container">
                <div class="content white-background">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="title-header">
                                <div class="row display-table">
                                    <div class="col-sm-8 vertical-align">
                                        <h5 class="title"><a href="category.html">Womens Popular</a></h5>
                                    </div><!-- end col -->
                                    <div class="col-sm-4 vertical-align">
                                        <div class="filter">
                                            <form class="form-horizontal">
                                                <div class="form-group">
                                                    <label for="women-filter-cat" class="col-sm-4 control-label">Filter</label>
                                                    <div class="col-sm-8">
                                                        <select id="women-filter-cat" class="form-control" name="women-filter-cat">
                                                            <option value="all">All Categories</option>
                                                            <option value="bresses">Bresses</option>
                                                            <option value="t-shirts">T-Shirts</option>
                                                            <option value="skirts">Skirts</option>
                                                            <option value="jeans">Jeans</option>
                                                            <option value="pullover">Pullover</option>
                                                        </select>
                                                    </div><!-- end col -->
                                                </div><!-- end form-group -->
                                            </form>
                                        </div><!-- end filter -->
                                    </div><!-- end col -->
                                </div><!-- end row -->
                            </div><!-- end title-header -->
                        </div><!-- end col -->
                    </div><!-- end row -->
                    
                    <div class="row column-4">
                        <div class="col-sm-6 col-md-3">
                            <div class="thumbnail store style2">
                                <div class="header">
                                    <div class="badges">
                                        <span class="product-badge top left white-backgorund text-primary semi-circle">Popular</span>
                                        <span class="product-badge top right text-warning">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star-half-o"></i>
                                        </span>
                                    </div>
                                    <figure>
                                        <a href="javascript:void(0);">
                                            <img class="front" src="img/products/women_01.jpg" alt="">
                                            <img class="back" src="img/products/women_02.jpg" alt="">
                                        </a>
                                    </figure>
                                    <div class="icons">
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-heart-o"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-gift"></i></a>
                                        <a class="icon" href="javascript:void(0);" data-toggle="modal" data-target=".productQuickView"><i class="fa fa-search"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-cart-plus mr-5"></i>Add to cart</a>
                                    </div>
                                </div>
                                <div class="caption">
                                    <h6 class="regular"><a href="shop-single-product-v1.html">Lorem Ipsum dolor sit</a></h6>
                                    <div class="price">
                                        <small class="amount off">$68.99</small>
                                        <span class="amount text-primary">$59.99</span>
                                    </div>
                                </div><!-- end caption -->
                            </div><!-- end thumbnail -->
                        </div><!-- end col -->
                        <div class="col-sm-6 col-md-3">
                            <div class="thumbnail store style2">
                                <div class="header">
                                    <div class="badges">
                                        <span class="product-badge top left text-warning">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star-half-o"></i>
                                        </span>
                                    </div>
                                    <figure>
                                        <a href="javascript:void(0);">
                                            <img src="img/products/women_03.jpg" alt="">
                                        </a>
                                    </figure>
                                    <div class="icons">
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-heart-o"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-gift"></i></a>
                                        <a class="icon" href="javascript:void(0);" data-toggle="modal" data-target=".productQuickView"><i class="fa fa-search"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-cart-plus mr-5"></i>Add to cart</a>
                                    </div>
                                </div>
                                <div class="caption">
                                    <h6 class="regular"><a href="shop-single-product-v1.html">Lorem Ipsum dolor sit</a></h6>
                                    <div class="price">
                                        <small class="amount off">$68.99</small>
                                        <span class="amount text-primary">$59.99</span>
                                    </div>
                                </div><!-- end caption -->
                            </div><!-- end thumbnail -->
                        </div><!-- end col -->
                        <div class="col-sm-6 col-md-3">
                            <div class="thumbnail store style2">
                                <div class="header">
                                    <div class="badges">
                                        <span class="product-badge top right white-backgorund text-warning semi-circle">Out of stock</span>
                                    </div>
                                    <figure class="layer">
                                        <a href="javascript:void(0);">
                                            <img src="img/products/women_04.jpg" alt="">
                                        </a>
                                    </figure>
                                    <div class="icons">
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-heart-o"></i></a>
                                        <a class="icon" href="javascript:void(0);" data-toggle="modal" data-target=".productQuickView"><i class="fa fa-search"></i></a>
                                    </div>
                                </div>
                                <div class="caption">
                                    <h6 class="regular"><a href="shop-single-product-v1.html">Lorem Ipsum dolor sit</a></h6>
                                    <div class="price">
                                        <small class="amount off">$68.99</small>
                                        <span class="amount text-primary">$59.99</span>
                                    </div>
                                </div><!-- end caption -->
                            </div><!-- end thumbnail -->
                        </div><!-- end col -->
                        <div class="col-sm-6 col-md-3">
                            <div class="thumbnail store style2">
                                <div class="header">
                                    <div class="badges">
                                        <span class="product-badge top right info-background text-white semi-circle">-30%</span>
                                        <span class="product-badge top left white-backgorund text-danger semi-circle">Sale</span>
                                    </div>
                                    <figure>
                                        <a href="javascript:void(0);">
                                            <img src="img/products/women_05.jpg" alt="">
                                        </a>
                                    </figure>
                                    <div class="icons">
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-heart-o"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-gift"></i></a>
                                        <a class="icon" href="javascript:void(0);" data-toggle="modal" data-target=".productQuickView"><i class="fa fa-search"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-cart-plus mr-5"></i>Add to cart</a>
                                    </div>
                                </div>
                                <div class="caption">
                                    <h6 class="regular"><a href="shop-single-product-v1.html">Lorem Ipsum dolor sit</a></h6>
                                    <div class="price">
                                        <small class="amount off">$68.99</small>
                                        <span class="amount text-primary">$59.99</span>
                                    </div>
                                </div><!-- end caption -->
                            </div><!-- end thumbnail -->
                        </div><!-- end col -->
                    </div><!-- end row -->
                </div><!-- end content -->
            </div><!-- end container -->
        </section>
        <!-- end section -->
        
        <!-- start section -->
        <section class="light-backgorund">
            <div class="container">
                <div class="content white-background">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="title-header">
                                <div class="row display-table">
                                    <div class="col-sm-8 vertical-align">
                                        <h5 class="title"><a href="category.html">Technology Popular</a></h5>
                                    </div><!-- end col -->
                                    <div class="col-sm-4 vertical-align">
                                        <div class="filter">
                                            <form class="form-horizontal">
                                                <div class="form-group">
                                                    <label for="tech-filter-cat" class="col-sm-4 control-label">Filter</label>
                                                    <div class="col-sm-8">
                                                        <select id="tech-filter-cat" class="form-control" name="tech-filter-cat">
                                                            <option value="all">All Categories</option>
                                                            <option value="tv">TV</option>
                                                            <option value="camera">Camera</option>
                                                            <option value="speakers">Speakers</option>
                                                            <option value="mobile">Mobile</option>
                                                            <option value="pc">PC</option>
                                                        </select>
                                                    </div><!-- end col -->
                                                </div><!-- end form-group -->
                                            </form>
                                        </div><!-- end filter -->
                                    </div><!-- end col -->
                                </div><!-- end row -->
                            </div><!-- end title-header -->
                        </div><!-- end col -->
                    </div><!-- end row -->
                    
                    <div class="row column-4">
                        <div class="col-sm-6 col-md-3">
                            <div class="thumbnail store style2">
                                <div class="header">
                                    <div class="badges">
                                        <span class="product-badge top left white-backgorund text-primary semi-circle">Popular</span>
                                        <span class="product-badge top right text-warning">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star-half-o"></i>
                                        </span>
                                    </div>
                                    <figure>
                                        <a href="javascript:void(0);">
                                            <img src="img/products/technology_01.jpg" alt="">
                                        </a>
                                    </figure>
                                    <div class="icons">
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-heart-o"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-gift"></i></a>
                                        <a class="icon" href="javascript:void(0);" data-toggle="modal" data-target=".productQuickView"><i class="fa fa-search"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-cart-plus mr-5"></i>Add to cart</a>
                                    </div>
                                </div>
                                <div class="caption">
                                    <h6 class="regular"><a href="shop-single-product-v1.html">Lorem Ipsum dolor sit</a></h6>
                                    <div class="price">
                                        <small class="amount off">$68.99</small>
                                        <span class="amount text-primary">$59.99</span>
                                    </div>
                                </div><!-- end caption -->
                            </div><!-- end thumbnail -->
                        </div><!-- end col -->
                        <div class="col-sm-6 col-md-3">
                            <div class="thumbnail store style2">
                                <div class="header">
                                    <div class="badges">
                                        <span class="product-badge top left text-warning">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star-half-o"></i>
                                        </span>
                                    </div>
                                    <figure>
                                        <a href="javascript:void(0);">
                                            <img src="img/products/technology_02.jpg" alt="">
                                        </a>
                                    </figure>
                                    <div class="icons">
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-heart-o"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-gift"></i></a>
                                        <a class="icon" href="javascript:void(0);" data-toggle="modal" data-target=".productQuickView"><i class="fa fa-search"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-cart-plus mr-5"></i>Add to cart</a>
                                    </div>
                                </div>
                                <div class="caption">
                                    <h6 class="regular"><a href="shop-single-product-v1.html">Lorem Ipsum dolor sit</a></h6>
                                    <div class="price">
                                        <small class="amount off">$68.99</small>
                                        <span class="amount text-primary">$59.99</span>
                                    </div>
                                </div><!-- end caption -->
                            </div><!-- end thumbnail -->
                        </div><!-- end col -->
                        <div class="col-sm-6 col-md-3">
                            <div class="thumbnail store style2">
                                <div class="header">
                                    <div class="badges">
                                        <span class="product-badge top right white-backgorund text-warning semi-circle">Out of stock</span>
                                    </div>
                                    <figure class="layer">
                                        <a href="javascript:void(0);">
                                            <img src="img/products/technology_03.jpg" alt="">
                                        </a>
                                    </figure>
                                    <div class="icons">
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-heart-o"></i></a>
                                        <a class="icon" href="javascript:void(0);" data-toggle="modal" data-target=".productQuickView"><i class="fa fa-search"></i></a>
                                    </div>
                                </div>
                                <div class="caption">
                                    <h6 class="regular"><a href="shop-single-product-v1.html">Lorem Ipsum dolor sit</a></h6>
                                    <div class="price">
                                        <small class="amount off">$68.99</small>
                                        <span class="amount text-primary">$59.99</span>
                                    </div>
                                </div><!-- end caption -->
                            </div><!-- end thumbnail -->
                        </div><!-- end col -->
                        <div class="col-sm-6 col-md-3">
                            <div class="thumbnail store style2">
                                <div class="header">
                                    <div class="badges">
                                        <span class="product-badge top right info-background text-white semi-circle">-30%</span>
                                        <span class="product-badge top left white-backgorund text-danger semi-circle">Sale</span>
                                    </div>
                                    <figure>
                                        <a href="javascript:void(0);">
                                            <img src="img/products/technology_04.jpg" alt="">
                                        </a>
                                    </figure>
                                    <div class="icons">
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-heart-o"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-gift"></i></a>
                                        <a class="icon" href="javascript:void(0);" data-toggle="modal" data-target=".productQuickView"><i class="fa fa-search"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-cart-plus mr-5"></i>Add to cart</a>
                                    </div>
                                </div>
                                <div class="caption">
                                    <h6 class="regular"><a href="shop-single-product-v1.html">Lorem Ipsum dolor sit</a></h6>
                                    <div class="price">
                                        <small class="amount off">$68.99</small>
                                        <span class="amount text-primary">$59.99</span>
                                    </div>
                                </div><!-- end caption -->
                            </div><!-- end thumbnail -->
                        </div><!-- end col -->
                    </div><!-- end row -->
                </div><!-- end content -->
            </div><!-- end container -->
        </section>
        <!-- end section -->
        
        <!-- start section -->
        <section class="light-backgorund">
            <div class="container">
                <div class="content white-background">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="title-header">
                                <h5 class="title"><a href="category.html">Kids Popular</a></h5>
                            </div><!-- end title-header -->
                        </div><!-- end col -->
                    </div><!-- end row -->
                    
                    <div class="row column-4">
                        <div class="col-sm-6 col-md-3">
                            <div class="thumbnail store style2">
                                <div class="header">
                                    <div class="badges">
                                        <span class="product-badge top left white-backgorund text-primary semi-circle">Popular</span>
                                        <span class="product-badge top right text-warning">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star-half-o"></i>
                                        </span>
                                    </div>
                                    <figure>
                                        <a href="javascript:void(0);">
                                            <img src="img/products/kids_01.jpg" alt="">
                                        </a>
                                    </figure>
                                    <div class="icons">
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-heart-o"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-gift"></i></a>
                                        <a class="icon" href="javascript:void(0);" data-toggle="modal" data-target=".productQuickView"><i class="fa fa-search"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-cart-plus mr-5"></i>Add to cart</a>
                                    </div>
                                </div>
                                <div class="caption">
                                    <h6 class="regular"><a href="shop-single-product-v1.html">Lorem Ipsum dolor sit</a></h6>
                                    <div class="price">
                                        <small class="amount off">$68.99</small>
                                        <span class="amount text-primary">$59.99</span>
                                    </div>
                                </div><!-- end caption -->
                            </div><!-- end thumbnail -->
                        </div><!-- end col -->
                        <div class="col-sm-6 col-md-3">
                            <div class="thumbnail store style2">
                                <div class="header">
                                    <div class="badges">
                                        <span class="product-badge top left text-warning">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star-half-o"></i>
                                        </span>
                                    </div>
                                    <figure>
                                        <a href="javascript:void(0);">
                                            <img src="img/products/kids_02.jpg" alt="">
                                        </a>
                                    </figure>
                                    <div class="icons">
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-heart-o"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-gift"></i></a>
                                        <a class="icon" href="javascript:void(0);" data-toggle="modal" data-target=".productQuickView"><i class="fa fa-search"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-cart-plus mr-5"></i>Add to cart</a>
                                    </div>
                                </div>
                                <div class="caption">
                                    <h6 class="regular"><a href="shop-single-product-v1.html">Lorem Ipsum dolor sit</a></h6>
                                    <div class="price">
                                        <small class="amount off">$68.99</small>
                                        <span class="amount text-primary">$59.99</span>
                                    </div>
                                </div><!-- end caption -->
                            </div><!-- end thumbnail -->
                        </div><!-- end col -->
                        <div class="col-sm-6 col-md-3">
                            <div class="thumbnail store style2">
                                <div class="header">
                                    <div class="badges">
                                        <span class="product-badge top right white-backgorund text-warning semi-circle">Out of stock</span>
                                    </div>
                                    <figure class="layer">
                                        <a href="javascript:void(0);">
                                            <img src="img/products/kids_03.jpg" alt="">
                                        </a>
                                    </figure>
                                    <div class="icons">
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-heart-o"></i></a>
                                        <a class="icon" href="javascript:void(0);" data-toggle="modal" data-target=".productQuickView"><i class="fa fa-search"></i></a>
                                    </div>
                                </div>
                                <div class="caption">
                                    <h6 class="regular"><a href="shop-single-product-v1.html">Lorem Ipsum dolor sit</a></h6>
                                    <div class="price">
                                        <small class="amount off">$68.99</small>
                                        <span class="amount text-primary">$59.99</span>
                                    </div>
                                </div><!-- end caption -->
                            </div><!-- end thumbnail -->
                        </div><!-- end col -->
                        <div class="col-sm-6 col-md-3">
                            <div class="thumbnail store style2">
                                <div class="header">
                                    <div class="badges">
                                        <span class="product-badge top right info-background text-white semi-circle">-30%</span>
                                        <span class="product-badge top left white-backgorund text-danger semi-circle">Sale</span>
                                    </div>
                                    <figure>
                                        <a href="javascript:void(0);">
                                            <img src="img/products/kids_04.jpg" alt="">
                                        </a>
                                    </figure>
                                    <div class="icons">
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-heart-o"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-gift"></i></a>
                                        <a class="icon" href="javascript:void(0);" data-toggle="modal" data-target=".productQuickView"><i class="fa fa-search"></i></a>
                                        <a class="icon" href="javascript:void(0);"><i class="fa fa-cart-plus mr-5"></i>Add to cart</a>
                                    </div>
                                </div>
                                <div class="caption">
                                    <h6 class="regular"><a href="shop-single-product-v1.html">Lorem Ipsum dolor sit</a></h6>
                                    <div class="price">
                                        <small class="amount off">$68.99</small>
                                        <span class="amount text-primary">$59.99</span>
                                    </div>
                                </div><!-- end caption -->
                            </div><!-- end thumbnail -->
                        </div><!-- end col -->
                    </div><!-- end row -->
                </div><!-- end content -->
            </div><!-- end container -->
        </section>
        <!-- end section -->
        
        <!-- start section -->
        <section class="light-backgorund">
            <div class="container">
                <div class="content danger-background">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="title-header">
                                <h5 class="title text-white">Hot Products</h5>
                            </div><!-- end title-header -->
                        </div><!-- end col -->
                    </div><!-- end row -->
                    
                    <div class="row column-4">
                        <div class="col-sm-6 col-md-3">
                            <div class="thumbnail store style3">
                                <div class="header">
                                    <div class="badges">
                                        <span class="product-badge top right text-warning">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star-half-o"></i>
                                        </span>
                                    </div>
                                    <figure>
                                        <a href="javascript:void(0);">
                                            <img src="img/products/bags_09.jpg" alt="">
                                        </a>
                                    </figure>
                                    <div class="icons">
                                        <a class="icon semi-circle" href="javascript:void(0);"><i class="fa fa-heart-o"></i></a>
                                        <a class="icon semi-circle" href="javascript:void(0);"><i class="fa fa-gift"></i></a>
                                        <a class="icon semi-circle" href="javascript:void(0);" data-toggle="modal" data-target=".productQuickView"><i class="fa fa-search"></i></a>
                                    </div>
                                </div>
                                <div class="caption">
                                    <h6 class="regular"><a href="shop-single-product-v1.html">Lorem Ipsum dolor sit</a></h6>
                                    <div class="price">
                                        <small class="amount off">$68.99</small>
                                        <span class="amount text-primary">$59.99</span>
                                    </div>
                                </div><!-- end caption -->
                            </div><!-- end thumbnail -->
                        </div><!-- end col -->
                        <div class="col-sm-6 col-md-3">
                            <div class="thumbnail store style3">
                                <div class="header">
                                    <div class="badges">
                                        <span class="product-badge top right text-warning">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star-half-o"></i>
                                        </span>
                                    </div>
                                    <figure>
                                        <a href="javascript:void(0);">
                                            <img src="img/products/fashion_01.jpg" alt="">
                                        </a>
                                    </figure>
                                    <div class="icons">
                                        <a class="icon semi-circle" href="javascript:void(0);"><i class="fa fa-heart-o"></i></a>
                                        <a class="icon semi-circle" href="javascript:void(0);"><i class="fa fa-gift"></i></a>
                                        <a class="icon semi-circle" href="javascript:void(0);" data-toggle="modal" data-target=".productQuickView"><i class="fa fa-search"></i></a>
                                    </div>
                                </div>
                                <div class="caption">
                                    <h6 class="regular"><a href="shop-single-product-v1.html">Lorem Ipsum dolor sit</a></h6>
                                    <div class="price">
                                        <small class="amount off">$68.99</small>
                                        <span class="amount text-primary">$59.99</span>
                                    </div>
                                </div><!-- end caption -->
                            </div><!-- end thumbnail -->
                        </div><!-- end col -->
                        <div class="col-sm-6 col-md-3">
                            <div class="thumbnail store style3">
                                <div class="header">
                                    <div class="badges">
                                        <span class="product-badge top right text-warning">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star-half-o"></i>
                                        </span>
                                    </div>
                                    <figure>
                                        <a href="javascript:void(0);">
                                            <img src="img/products/hoseholds_02.jpg" alt="">
                                        </a>
                                    </figure>
                                    <div class="icons">
                                        <a class="icon semi-circle" href="javascript:void(0);"><i class="fa fa-heart-o"></i></a>
                                        <a class="icon semi-circle" href="javascript:void(0);"><i class="fa fa-gift"></i></a>
                                        <a class="icon semi-circle" href="javascript:void(0);" data-toggle="modal" data-target=".productQuickView"><i class="fa fa-search"></i></a>
                                    </div>
                                </div>
                                <div class="caption">
                                    <h6 class="regular"><a href="shop-single-product-v1.html">Lorem Ipsum dolor sit</a></h6>
                                    <div class="price">
                                        <small class="amount off">$68.99</small>
                                        <span class="amount text-primary">$59.99</span>
                                    </div>
                                </div><!-- end caption -->
                            </div><!-- end thumbnail -->
                        </div><!-- end col -->
                        <div class="col-sm-6 col-md-3">
                            <div class="thumbnail store style3">
                                <div class="header">
                                    <div class="badges">
                                        <span class="product-badge top right text-warning">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star-half-o"></i>
                                        </span>
                                    </div>
                                    <figure>
                                        <a href="javascript:void(0);">
                                            <img src="img/products/kids_05.jpg" alt="">
                                        </a>
                                    </figure>
                                    <div class="icons">
                                        <a class="icon semi-circle" href="javascript:void(0);"><i class="fa fa-heart-o"></i></a>
                                        <a class="icon semi-circle" href="javascript:void(0);"><i class="fa fa-gift"></i></a>
                                        <a class="icon semi-circle" href="javascript:void(0);" data-toggle="modal" data-target=".productQuickView"><i class="fa fa-search"></i></a>
                                    </div>
                                </div>
                                <div class="caption">
                                    <h6 class="regular"><a href="shop-single-product-v1.html">Lorem Ipsum dolor sit</a></h6>
                                    <div class="price">
                                        <small class="amount off">$68.99</small>
                                        <span class="amount text-primary">$59.99</span>
                                    </div>
                                </div><!-- end caption -->
                            </div><!-- end thumbnail -->
                        </div><!-- end col -->
                        <div class="col-sm-6 col-md-3">
                            <div class="thumbnail store style3">
                                <div class="header">
                                    <div class="badges">
                                        <span class="product-badge top right text-warning">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star-half-o"></i>
                                        </span>
                                    </div>
                                    <figure>
                                        <a href="javascript:void(0);">
                                            <img src="img/products/men_06.jpg" alt="">
                                        </a>
                                    </figure>
                                    <div class="icons">
                                        <a class="icon semi-circle" href="javascript:void(0);"><i class="fa fa-heart-o"></i></a>
                                        <a class="icon semi-circle" href="javascript:void(0);"><i class="fa fa-gift"></i></a>
                                        <a class="icon semi-circle" href="javascript:void(0);" data-toggle="modal" data-target=".productQuickView"><i class="fa fa-search"></i></a>
                                    </div>
                                </div>
                                <div class="caption">
                                    <h6 class="regular"><a href="shop-single-product-v1.html">Lorem Ipsum dolor sit</a></h6>
                                    <div class="price">
                                        <small class="amount off">$68.99</small>
                                        <span class="amount text-primary">$59.99</span>
                                    </div>
                                </div><!-- end caption -->
                            </div><!-- end thumbnail -->
                        </div><!-- end col -->
                        <div class="col-sm-6 col-md-3">
                            <div class="thumbnail store style3">
                                <div class="header">
                                    <div class="badges">
                                        <span class="product-badge top right text-warning">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star-half-o"></i>
                                        </span>
                                    </div>
                                    <figure>
                                        <a href="javascript:void(0);">
                                            <img src="img/products/shoes_01.jpg" alt="">
                                        </a>
                                    </figure>
                                    <div class="icons">
                                        <a class="icon semi-circle" href="javascript:void(0);"><i class="fa fa-heart-o"></i></a>
                                        <a class="icon semi-circle" href="javascript:void(0);"><i class="fa fa-gift"></i></a>
                                        <a class="icon semi-circle" href="javascript:void(0);" data-toggle="modal" data-target=".productQuickView"><i class="fa fa-search"></i></a>
                                    </div>
                                </div>
                                <div class="caption">
                                    <h6 class="regular"><a href="shop-single-product-v1.html">Lorem Ipsum dolor sit</a></h6>
                                    <div class="price">
                                        <small class="amount off">$68.99</small>
                                        <span class="amount text-primary">$59.99</span>
                                    </div>
                                </div><!-- end caption -->
                            </div><!-- end thumbnail -->
                        </div><!-- end col -->
                        <div class="col-sm-6 col-md-3">
                            <div class="thumbnail store style3">
                                <div class="header">
                                    <div class="badges">
                                        <span class="product-badge top right text-warning">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star-half-o"></i>
                                        </span>
                                    </div>
                                    <figure>
                                        <a href="javascript:void(0);">
                                            <img src="img/products/men_08.jpg" alt="">
                                        </a>
                                    </figure>
                                    <div class="icons">
                                        <a class="icon semi-circle" href="javascript:void(0);"><i class="fa fa-heart-o"></i></a>
                                        <a class="icon semi-circle" href="javascript:void(0);"><i class="fa fa-gift"></i></a>
                                        <a class="icon semi-circle" href="javascript:void(0);" data-toggle="modal" data-target=".productQuickView"><i class="fa fa-search"></i></a>
                                    </div>
                                </div>
                                <div class="caption">
                                    <h6 class="regular"><a href="shop-single-product-v1.html">Lorem Ipsum dolor sit</a></h6>
                                    <div class="price">
                                        <small class="amount off">$68.99</small>
                                        <span class="amount text-primary">$59.99</span>
                                    </div>
                                </div><!-- end caption -->
                            </div><!-- end thumbnail -->
                        </div><!-- end col -->
                        <div class="col-sm-6 col-md-3">
                            <div class="thumbnail store style3">
                                <div class="header">
                                    <div class="badges">
                                        <span class="product-badge top right text-warning">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star-half-o"></i>
                                        </span>
                                    </div>
                                    <figure>
                                        <a href="javascript:void(0);">
                                            <img src="img/products/technology_08.jpg" alt="">
                                        </a>
                                    </figure>
                                    <div class="icons">
                                        <a class="icon semi-circle" href="javascript:void(0);"><i class="fa fa-heart-o"></i></a>
                                        <a class="icon semi-circle" href="javascript:void(0);"><i class="fa fa-gift"></i></a>
                                        <a class="icon semi-circle" href="javascript:void(0);" data-toggle="modal" data-target=".productQuickView"><i class="fa fa-search"></i></a>
                                    </div>
                                </div>
                                <div class="caption">
                                    <h6 class="regular"><a href="shop-single-product-v1.html">Lorem Ipsum dolor sit</a></h6>
                                    <div class="price">
                                        <small class="amount off">$68.99</small>
                                        <span class="amount text-primary">$59.99</span>
                                    </div>
                                </div><!-- end caption -->
                            </div><!-- end thumbnail -->
                        </div><!-- end col -->
                    </div><!-- end row -->
                </div><!-- end content -->
            </div><!-- end container -->
        </section>
        <!-- end section -->
        
        <!-- start section -->
        <section>
            <div class="container">
                <!-- Modal Product Quick View -->
                <div class="modal fade productQuickView" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                    <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <h5>Lorem ipsum dolar sit amet</h5>
                            </div><!-- end modal-header -->
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-sm-5">
                                        <div class='carousel slide product-slider' data-ride='carousel' data-interval="false">
                                            <div class='carousel-inner'>
                                                <div class='item active'>
                                                    <figure>
                                                        <img src='img/products/men_01.jpg' alt='' />
                                                    </figure>
                                                </div><!-- end item -->
                                                <div class='item'>
                                                    <div class="embed-responsive embed-responsive-16by9">
                                                        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/NrmMk1Myrxc"></iframe>
                                                    </div>
                                                </div><!-- end item -->
                                                <div class='item'>
                                                    <figure>
                                                        <img src='img/products/men_03.jpg' alt='' />
                                                    </figure>
                                                </div><!-- end item -->
                                                <div class='item'>
                                                    <figure>
                                                        <img src='img/products/men_04.jpg' alt='' />
                                                    </figure>
                                                </div><!-- end item -->
                                                <div class='item'>
                                                    <figure>
                                                        <img src='img/products/men_05.jpg' alt=''/>
                                                    </figure>
                                                </div><!-- end item -->

                                                <!-- Arrows -->
                                                <a class='left carousel-control' href='.product-slider' data-slide='prev'>
                                                    <span class='fa fa-angle-left'></span>
                                                </a>
                                                <a class='right carousel-control' href='.product-slider' data-slide='next'>
                                                    <span class='fa fa-angle-right'></span>
                                                </a>
                                            </div><!-- end carousel-inner -->

                                            <!-- thumbs -->
                                            <ol class='carousel-indicators mCustomScrollbar meartlab'>
                                                <li data-target='.product-slider' data-slide-to='0' class='active'><img src='img/products/men_01.jpg' alt='' /></li>
                                                <li data-target='.product-slider' data-slide-to='1'><img src='img/products/men_02.jpg' alt='' /></li>
                                                <li data-target='.product-slider' data-slide-to='2'><img src='img/products/men_03.jpg' alt='' /></li>
                                                <li data-target='.product-slider' data-slide-to='3'><img src='img/products/men_04.jpg' alt='' /></li>
                                                <li data-target='.product-slider' data-slide-to='4'><img src='img/products/men_05.jpg' alt='' /></li>
                                                <li data-target='.product-slider' data-slide-to='5'><img src='img/products/men_06.jpg' alt='' /></li>
                                            </ol><!-- end carousel-indicators -->
                                        </div><!-- end carousel -->
                                    </div><!-- end col -->
                                    <div class="col-sm-7">
                                        <p class="text-gray alt-font">Product code: 1032446</p>

                                        <i class="fa fa-star text-warning"></i>
                                        <i class="fa fa-star text-warning"></i>
                                        <i class="fa fa-star text-warning"></i>
                                        <i class="fa fa-star text-warning"></i>
                                        <i class="fa fa-star-half-o text-warning"></i>
                                        <span>(12 reviews)</span>
                                        <h4 class="text-primary">$79.00</h4>
                                        <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.</p>
                                        <hr class="spacer-10">
                                        <div class="row">
                                            <div class="col-md-4 col-sm-6 col-xs-12">
                                                <select class="form-control" name="select">
                                                    <option value="" selected>Color</option>
                                                    <option value="red">Red</option>
                                                    <option value="green">Green</option>
                                                    <option value="blue">Blue</option>
                                                </select>
                                            </div><!-- end col -->
                                            <div class="col-md-4 col-sm-6 col-xs-12">
                                                <select class="form-control" name="select">
                                                    <option value="">Size</option>
                                                    <option value="">S</option>
                                                    <option value="">M</option>
                                                    <option value="">L</option>
                                                    <option value="">XL</option>
                                                    <option value="">XXL</option>
                                                </select>
                                            </div><!-- end col -->
                                            <div class="col-md-4 col-sm-12">
                                                <select class="form-control" name="select">
                                                    <option value="" selected>QTY</option>
                                                    <option value="">1</option>
                                                    <option value="">2</option>
                                                    <option value="">3</option>
                                                    <option value="">4</option>
                                                    <option value="">5</option>
                                                    <option value="">6</option>
                                                    <option value="">7</option>
                                                </select>
                                            </div><!-- end col -->
                                        </div><!-- end row -->
                                        <hr class="spacer-10">
                                        <ul class="list list-inline">
                                            <li><button type="button" class="btn btn-default btn-md round"><i class="fa fa-shopping-basket mr-5"></i>Add to Cart</button></li>
                                            <li><button type="button" class="btn btn-gray btn-md round"><i class="fa fa-heart mr-5"></i>Add to Wishlist</button></li>
                                        </ul>
                                    </div><!-- end col -->
                                </div><!-- end row -->
                            </div><!-- end modal-body -->
                        </div><!-- end modal-content -->
                    </div><!-- end modal-dialog -->
                </div><!-- end productRewiew -->
            </div><!-- end container -->
        </section>
        <!-- end section -->
        
        <!-- start section -->
        <section class="section image-background layer-dark" style="background-image: url(img/bg_01.jpg);">
            <div class="container">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="icon-boxes style2">
                            <div class="icon">
                                <i class="fa fa-book text-primary"></i>
                            </div><!-- end icon -->
                            <div class="box-content">
                                <h5 class="text-white">Customer Service</h5>
                                <p class="text-white">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                            </div>
                        </div><!-- icon-box -->
                    </div><!-- end col -->
                    <div class="col-sm-4">
                        <div class="icon-boxes style2">
                            <div class="icon">
                                <i class="fa fa-lightbulb-o text-info"></i>
                            </div><!-- end icon -->
                            <div class="box-content">
                                <h5 class="text-white">Seller Satisfaction</h5>
                                <p class="text-white">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                            </div>
                        </div><!-- icon-box -->
                    </div><!-- end col -->
                    <div class="col-sm-4">
                        <div class="icon-boxes style2">
                            <div class="icon">
                                <i class="fa fa-bullhorn text-warning"></i>
                            </div><!-- end icon -->
                            <div class="box-content">
                                <h5 class="text-white">Best Offers</h5>
                                <p class="text-white">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                            </div>
                        </div><!-- icon-box -->
                    </div><!-- end col -->
                </div><!-- end row -->
            </div><!-- end container -->
        </section>
        <!-- end section -->
        
        <!-- start footer -->
        <footer class="footer">
            <div class="container">
                <div class="row">
                    <div class="col-sm-3">
                        <div class="icon-boxes style1">
                            <div class="icon">
                                <i class="fa fa-truck text-gray"></i>
                            </div><!-- end icon -->
                            <div class="box-content">
                                <h6 class="alt-font text-light text-uppercase">Free Shipping</h6>
                                <p class="text-gray">Aenean semper lacus sed molestie sollicitudin.</p>
                            </div>
                        </div><!-- icon-box -->
                    </div><!-- end col -->
                    <div class="col-sm-3">
                        <div class="icon-boxes style1">
                            <div class="icon">
                                <i class="fa fa-life-ring text-gray"></i>
                            </div><!-- end icon -->
                            <div class="box-content">
                                <h6 class="alt-font text-light text-uppercase">Support 24/7</h6>
                                <p class="text-gray">Aenean semper lacus sed molestie sollicitudin.</p>
                            </div>
                        </div><!-- icon-box -->
                    </div><!-- end col -->
                    <div class="col-sm-3">
                        <div class="icon-boxes style1">
                            <div class="icon">
                                <i class="fa fa-gift text-gray"></i>
                            </div><!-- end icon -->
                            <div class="box-content">
                                <h6 class="alt-font text-light text-uppercase">Gift cards</h6>
                                <p class="text-gray">Aenean semper lacus sed molestie sollicitudin.</p>
                            </div>
                        </div><!-- icon-box -->
                    </div><!-- end col -->
                    <div class="col-sm-3">
                        <div class="icon-boxes style1">
                            <div class="icon">
                                <i class="fa fa-credit-card text-gray"></i>
                            </div><!-- end icon -->
                            <div class="box-content">
                                <h6 class="alt-font text-light text-uppercase">Payment 100% Secure</h6>
                                <p class="text-gray">Aenean semper lacus sed molestie sollicitudin.</p>
                            </div>
                        </div><!-- icon-box -->
                    </div><!-- end col -->
                </div><!-- end row -->
                
                <hr class="spacer-30">
                
                <div class="row">
                    <div class="col-sm-3">
                        <h5 class="title">Plus</h5>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin suscipit, libero a molestie consectetur, sapien elit lacinia mi.</p>
                        
                        <hr class="spacer-10 no-border">
                        
                        <ul class="social-icons">
                            <li class="facebook"><a href="javascript:void(0);"><i class="fa fa-facebook"></i></a></li>
                            <li class="twitter"><a href="javascript:void(0);"><i class="fa fa-twitter"></i></a></li>
                            <li class="dribbble"><a href="javascript:void(0);"><i class="fa fa-dribbble"></i></a></li>
                            <li class="linkedin"><a href="javascript:void(0);"><i class="fa fa-linkedin"></i></a></li>
                            <li class="youtube"><a href="javascript:void(0);"><i class="fa fa-youtube"></i></a></li>
                            <li class="behance"><a href="javascript:void(0);"><i class="fa fa-behance"></i></a></li>
                        </ul>
                    </div><!-- end col -->
                    <div class="col-sm-3">
                        <h5 class="title">My Account</h5>
                        <ul class="list alt-list">
                            <li><a href="my-account.html"><i class="fa fa-angle-right"></i>My Account</a></li>
                            <li><a href="wishlist.html"><i class="fa fa-angle-right"></i>Wishlist</a></li>
                            <li><a href="cart.html"><i class="fa fa-angle-right"></i>My Cart</a></li>
                            <li><a href="checkout.html"><i class="fa fa-angle-right"></i>Checkout</a></li>
                        </ul>
                    </div><!-- end col -->
                    <div class="col-sm-3">
                        <h5 class="title">Information</h5>
                        <ul class="list alt-list">
                            <li><a href="about-us-v1.html"><i class="fa fa-angle-right"></i>About Us</a></li>
                            <li><a href="faq.html"><i class="fa fa-angle-right"></i>FAQ</a></li>
                            <li><a href="privacy-policy.html"><i class="fa fa-angle-right"></i>Privacy Policy</a></li>
                            <li><a href="contact-v1.html"><i class="fa fa-angle-right"></i>Contact Us</a></li>
                        </ul>
                    </div><!-- end col -->
                    <div class="col-sm-3">
                        <h5 class="title">Payment Methods</h5>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                        <ul class="list list-inline">
                            <li class="text-white"><i class="fa fa-cc-visa fa-2x"></i></li>
                            <li class="text-white"><i class="fa fa-cc-paypal fa-2x"></i></li>
                            <li class="text-white"><i class="fa fa-cc-mastercard fa-2x"></i></li>
                            <li class="text-white"><i class="fa fa-cc-discover fa-2x"></i></li>
                        </ul>
                    </div><!-- end col -->
                </div><!-- end row -->
                
                <hr class="spacer-30">
                
                <div class="row text-center">
                    <div class="col-sm-12">
                        <p class="text-sm">&COPY; 2017. Made with <i class="fa fa-heart text-danger"></i> by <a href="javascript:void(0);">DiamondCreative.</a></p>
                    </div><!-- end col -->
                </div><!-- end row -->
            </div><!-- end container -->
        </footer>
        <!-- end footer -->
        
        
        <!-- JavaScript Files -->
        <script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <script type="text/javascript" src="js/owl.carousel.min.js"></script>
        <script type="text/javascript" src="js/jquery.downCount.js"></script>
        <script type="text/javascript" src="js/nouislider.min.js"></script>
        <script type="text/javascript" src="js/jquery.sticky.js"></script>
        <script type="text/javascript" src="js/pace.min.js"></script>
        <script type="text/javascript" src="js/star-rating.min.js"></script>
        <script type="text/javascript" src="js/wow.min.js"></script>
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>
        <script type="text/javascript" src="js/gmaps.js"></script>
        <script type="text/javascript" src="js/swiper.min.js"></script>
        <script type="text/javascript" src="js/main.js"></script>
        
    </body>
</html>