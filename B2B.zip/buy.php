<?php session_start();
require 'Connect.php';  
$show=0;
 if ($_SERVER['REQUEST_METHOD'] == 'POST'){
$user =$_SESSION['uemail'];
$prod_name=$_POST['pname'];
$description=$_POST['description'];

$target_dir = "ReqImages/";
$target_file = $target_dir . basename($_FILES["pimage"]["name"]);
$image=$_FILES['pimage']['name'];
$filelocation = $target_dir.$image;
$temp = $_FILES['pimage']['tmp_name'];
move_uploaded_file($temp, $filelocation);

 $query = "INSERT INTO buyerrequests(BuyerName,prod_name,bmessage,image,buyer_id) VALUES ('$user', '$prod_name','$description' ,'$image',0)";
 //echo $query;
 $result=mysqli_query($connection,$query); 
  	 if($result){
		 $show=1;
	 }
	 else{
		  $show=2;
	 }
		
		}          
 
 


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Buyers</title>
    <meta charset="utf-8">
    <meta name="description" content="Plus E-Commerce Template">
    <meta name="author" content="Diamant Gjota" />
    <meta name="keywords" content="plus, html5, css3, template, ecommerce, e-commerce, bootstrap, responsive, creative" />
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;">

    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
	
    <!--Favicon-->
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
    <link rel="icon" href="img/favicon.ico" type="image/x-icon">
    
    <!-- css files -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.min.css" />
    <link rel="stylesheet" type="text/css" href="css/owl.theme.default.min.css" />
    <link rel="stylesheet" type="text/css" href="css/animate.css" />
    <link rel="stylesheet" type="text/css" href="css/swiper.css" />
    
    <!-- this is default skin you can replace that with: dark.css, yellow.css, red.css ect -->
    <link id="pagestyle" rel="stylesheet" type="text/css" href="css/default.css" />
    
    <!-- Google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,700,700i,900,900i&subset=cyrillic,cyrillic-ext,latin-ext" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:100,300,400,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Dosis:200,300,400,500,600,700,800&amp;subset=latin-ext" rel="stylesheet">
    
</head>
    <body>
        
        <!-- start topBar -->
       <?php require 'topbar.php' ?>
        <!-- end topBar -->
        
        <!-- start navbar -->
        <div class="navbar yamm navbar-default">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" data-toggle="collapse" data-target="#navbar-collapse-1" class="navbar-toggle">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a href="javascript:void(0);" class="navbar-brand">
                        <img src="img/logo.png" alt="logo">
                    </a>
                </div>
                <div id="navbar-collapse-1" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <!-- Home -->
                        <li class="dropdown"><a href="index.php">Home</a>
                           
                        </li><!-- end li dropdown -->    
                        <!-- Features -->
                        <li class="dropdown left"><a href="#" data-toggle="dropdown" class="dropdown-toggle">Buyers<i class="fa fa-angle-down ml-5"></i></a>
                            <ul class="dropdown-menu">
                                <li><a href="#">Myrequests</a></li>
                                
                            </ul><!-- end ul dropdown-menu -->
                        </li><!-- end li dropdown -->
                        <!-- Pages -->
           
                        
                        <!-- Collections -->
              <!-- end dropdown -->
                    </ul><!-- end navbar-nav -->
                    
                </div><!-- end navbar collapse -->
            </div><!-- end container -->
        </div><!-- end navbar -->
        
    
        
		<section class="section white-backgorund" >
		<br>
           	<?php if($show==1){
              $smsg = '<div class="alert alert-success" id="suc">Successfuly Requested ! !</div>';
			  echo $smsg;
        }
	if($show==2) {
              $smsg = '<div class="alert alert-danger" id="fail">Failed!</div>';
			  echo $smsg;
        }
		?>
		   <div class="container">
               
			   
                <div class="row" style="padding-left:350px;">
                    <div class="col-sm-6">
					<h2 class="title">Request Sellers</h2>  <br>
                        <form method="POST" enctype="multipart/form-data">
                            <div class="form-group">
                                <label >Prodcut Name</label>
                                <input name="pname" type="text" id="firstname" class="form-control input-lg" placeholder="Product Name">
                            </div>
                           
                            
                        <!--    <div class="form-group">
                                <select class="form-control" name="select">
                                    <option>suplier1</option>
                                    <option>suplier2</option>
                                    <option>suplier3</option>
                                    <option>4</option>
                                    <option>5</option>
                                </select>
                            </div>
							-->
                            <div class="form-group">
                                <label for="pimage">Product Image</label>
                                <input type="file" name="pimage"  class="form-control input-lg">
                           
							   </div>
                           
                            <div class="form-group">
                                <label class="control-label" for="message" name="description">Descirption</label>
                                <textarea id="message" rows="5" class="form-control" placeholder="Description ..." name="description"></textarea>
                            </div>
                           
                            
                           
                            <div class="form-group">
                                <input type="submit" class="btn btn-success round btn-md" value="Request Now">
                            </div>
                        </form>
						
                    </div><!-- end col -->
                   
                       
                      
                        
                    </div><!-- end col -->    
                </div><!-- end row -->
				
            </div><!-- end container -->
        </section>
		
        
        <!-- start section -->
        <section class="section light-background">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="title-wrap">
                            <h2 class="title">Quotes of suppliers </h2>
                            <h6 class="subtitle">Lorem Ipsum dolar sit amet</h6>
                        </div>
                    </div><!-- end col -->
                </div><!-- end row -->
                
                <div class="row">
                    <div class="col-sm-4">
                        <div class="quote">
                            <span class="quote-mark alt-font">&#8220;</span>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut rhoncus magna a lacinia tempor. Fusce et turpis posuere, imperdiet orci et, tempus ex. Nunc vitae pellentesque ipsum.
                            </p>
                            <div class="quote-author">
                                <img class="author-img" src="img/team/team_01.jpg" />
                                <div class="author-name">John Doe</div>
                            </div>
                        </div><!-- end quote -->
                    </div><!-- end col -->
                    <div class="col-sm-4">
                        <div class="quote">
                            <span class="quote-mark alt-font">&#8220;</span>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut rhoncus magna a lacinia tempor. Fusce et turpis posuere, imperdiet orci et, tempus ex. Nunc vitae pellentesque ipsum.
                            </p>
                            <div class="quote-author">
                                <img class="author-img" src="img/team/team_02.jpg" />
                                <div class="author-name">John Doe</div>
                            </div>
                        </div><!-- end quote -->
                    </div><!-- end col -->
                    <div class="col-sm-4">
                        <div class="quote">
                            <span class="quote-mark alt-font">&#8220;</span>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut rhoncus magna a lacinia tempor. Fusce et turpis posuere, imperdiet orci et, tempus ex. Nunc vitae pellentesque ipsum.
                            </p>
                            <div class="quote-author">
                                <img class="author-img" src="img/team/team_03.jpg" />
                                <div class="author-name">Jane Doe</div>
                            </div>
                        </div><!-- end quote -->
                    </div><!-- end col -->
                </div><!-- end row -->
            </div><!-- end container -->
        </section>
        <!-- end section -->
            
        <!-- start section -->
        
        <!-- end section -->
        
    
        
        <!-- start section -->
        
        <!-- end section -->
        
        <!-- start section -->
        <section class="section light-backgorund">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="title-wrap">
                            <h2 class="title">Buy Products Below</h2>
                           
                        </div>
                    </div><!-- end col -->
                </div><!-- end row -->
                
               
                
                <hr class="spacer-30 no-border">
                <?php  
			   $query ="SELECT image ,ntitle,price FROM products";
               $result=mysqli_query($connection,$query);
			   ?>
			      
                <div class="row column-4">
				<?php
                  while( $row=mysqli_fetch_array($result)){ ?>
                    <div class="col-sm-6 col-md-3">
                        <div class="thumbnail store style1">
                            <div class="header">
                                <figure class="zoom-in">
                                    <a href="javascript:void(0);">
                                        <img class="front" src="images/<?php echo $row['image']; ?>" alt="">
                                        <img class="back" src="images/<?php echo $row['image']; ?>" alt="">
                                    </a>
                                </figure>
                            </div>
                            <div class="caption">
                                <h6 class="regular"><a href="#"><?php echo $row['ntitle']; ?></a></h6>
                                <div class="price">
                                   <!-- <small class="amount off">$68.99</small>  -->
                                    <span class="amount text-primary"><?php echo $row['price']; ?></span>
                                </div>
                             <!--   <span class="product-badge bottom left text-warning">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star-half-o"></i>
                                    <i class="fa fa-star-o"></i>
                                </span>  -->
                               
                            </div><!-- end caption -->
                        </div><!-- end thumbnail -->
                    </div><!-- end col -->
                   <?php  } ?>
                   
                </div><!-- end row -->
                

                
                
                
                <hr class="spacer-30 no-border">
                
                
               
        </section>
        <!-- end section -->
        
        <!-- start section -->
        <section class="section white-backgorund">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="title-wrap">
                            <h1 class="title">Carousels</h4>
                        </div>
                    </div><!-- end col -->
                </div><!-- end row -->
                
               
         
                
                <hr class="spacer-30 no-border">
                
                <div class="row">
                    <div class="col-sm-12">
                        <h4 class="mb-20">You May Also Like</h4>
                    </div><!-- end col -->
                </div><!-- end row -->
                
                <div id="owl-demo" class="owl-carousel column-4 owl-theme">
                    <div class="item">
                        <div class="thumbnail store style1">
                            <div class="header">
                                <figure>
                                    <a href="shop-single-product-v1.html">
                                        <img src="img/products/bags_03.jpg" alt="">
                                    </a>
                                </figure>
                            </div>
                            <div class="caption">
                                <h6 class="regular"><a href="shop-single-product-v1.html">Printed Summer Dress</a></h6>
                                <div class="price">
                                    <small class="amount off">$68.99</small>
                                    <span class="amount text-primary">$59.99</span>
                                </div>
                                <span class="product-badge bottom left text-warning">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star-half-o"></i>
                                    <i class="fa fa-star-o"></i>
                                </span>
                            </div><!-- end caption -->
                        </div><!-- end thumbnail -->
                        
                        <div class="thumbnail store style1">
                            <div class="header">
                                <figure>
                                    <a href="shop-single-product-v1.html">
                                        <img src="img/products/bags_06.jpg" alt="">
                                    </a>
                                </figure>
                            </div>
                            <div class="caption">
                                <h6 class="regular"><a href="shop-single-product-v1.html">Printed Summer Dress</a></h6>
                                <div class="price">
                                    <small class="amount off">$68.99</small>
                                    <span class="amount text-primary">$59.99</span>
                                </div>
                                <span class="product-badge bottom left text-warning">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star-half-o"></i>
                                    <i class="fa fa-star-o"></i>
                                </span>
                            </div><!-- end caption -->
                        </div><!-- end thumbnail -->
                    </div><!-- end item -->
                    <div class="item">
                        <div class="thumbnail store style1">
                            <div class="header">
                                <figure>
                                    <a href="shop-single-product-v1.html">
                                        <img src="img/products/hoseholds_01.jpg" alt="">
                                    </a>
                                </figure>
                            </div>
                            <div class="caption">
                                <h6 class="regular"><a href="shop-single-product-v1.html">Printed Summer Dress</a></h6>
                                <div class="price">
                                    <small class="amount off">$68.99</small>
                                    <span class="amount text-primary">$59.99</span>
                                </div>
                                <span class="product-badge bottom left text-warning">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star-half-o"></i>
                                    <i class="fa fa-star-o"></i>
                                </span>
                            </div><!-- end caption -->
                        </div><!-- end thumbnail -->
                        
                        <div class="thumbnail store style1">
                            <div class="header">
                                <figure>
                                    <a href="shop-single-product-v1.html">
                                        <img src="img/products/fashion_02.jpg" alt="">
                                    </a>
                                </figure>
                            </div>
                            <div class="caption">
                                <h6 class="regular"><a href="shop-single-product-v1.html">Printed Summer Dress</a></h6>
                                <div class="price">
                                    <small class="amount off">$68.99</small>
                                    <span class="amount text-primary">$59.99</span>
                                </div>
                                <span class="product-badge bottom left text-warning">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star-half-o"></i>
                                    <i class="fa fa-star-o"></i>
                                </span>
                            </div><!-- end caption -->
                        </div><!-- end thumbnail -->
                    </div><!-- end item -->
                    <div class="item">
                        <div class="thumbnail store style1">
                            <div class="header">
                                <figure>
                                    <a href="shop-single-product-v1.html">
                                        <img src="img/products/hoseholds_03.jpg" alt="">
                                    </a>
                                </figure>
                            </div>
                            <div class="caption">
                                <h6 class="regular"><a href="shop-single-product-v1.html">Printed Summer Dress</a></h6>
                                <div class="price">
                                    <small class="amount off">$68.99</small>
                                    <span class="amount text-primary">$59.99</span>
                                </div>
                                <span class="product-badge bottom left text-warning">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star-half-o"></i>
                                    <i class="fa fa-star-o"></i>
                                </span>
                            </div><!-- end caption -->
                        </div><!-- end thumbnail -->
                        
                        <div class="thumbnail store style1">
                            <div class="header">
                                <figure>
                                    <a href="shop-single-product-v1.html">
                                        <img src="img/products/kids_06.jpg" alt="">
                                    </a>
                                </figure>
                            </div>
                            <div class="caption">
                                <h6 class="regular"><a href="shop-single-product-v1.html">Printed Summer Dress</a></h6>
                                <div class="price">
                                    <small class="amount off">$68.99</small>
                                    <span class="amount text-primary">$59.99</span>
                                </div>
                                <span class="product-badge bottom left text-warning">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star-half-o"></i>
                                    <i class="fa fa-star-o"></i>
                                </span>
                            </div><!-- end caption -->
                        </div><!-- end thumbnail -->
                    </div><!-- end item -->
                    <div class="item">
                        <div class="thumbnail store style1">
                            <div class="header">
                                <figure>
                                    <a href="shop-single-product-v1.html">
                                        <img src="img/products/men_03.jpg" alt="">
                                    </a>
                                </figure>
                            </div>
                            <div class="caption">
                                <h6 class="regular"><a href="shop-single-product-v1.html">Printed Summer Dress</a></h6>
                                <div class="price">
                                    <small class="amount off">$68.99</small>
                                    <span class="amount text-primary">$59.99</span>
                                </div>
                                <span class="product-badge bottom left text-warning">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star-half-o"></i>
                                    <i class="fa fa-star-o"></i>
                                </span>
                            </div><!-- end caption -->
                        </div><!-- end thumbnail -->
                        
                        <div class="thumbnail store style1">
                            <div class="header">
                                <figure>
                                    <a href="shop-single-product-v1.html">
                                        <img src="img/products/men_06.jpg" alt="">
                                    </a>
                                </figure>
                            </div>
                            <div class="caption">
                                <h6 class="regular"><a href="shop-single-product-v1.html">Printed Summer Dress</a></h6>
                                <div class="price">
                                    <small class="amount off">$68.99</small>
                                    <span class="amount text-primary">$59.99</span>
                                </div>
                                <span class="product-badge bottom left text-warning">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star-half-o"></i>
                                    <i class="fa fa-star-o"></i>
                                </span>
                            </div><!-- end caption -->
                        </div><!-- end thumbnail -->
                    </div><!-- end item -->
                    <div class="item">
                        <div class="thumbnail store style1">
                            <div class="header">
                                <figure>
                                    <a href="shop-single-product-v1.html">
                                        <img src="img/products/women_01.jpg" alt="">
                                    </a>
                                </figure>
                            </div>
                            <div class="caption">
                                <h6 class="regular"><a href="shop-single-product-v1.html">Printed Summer Dress</a></h6>
                                <div class="price">
                                    <small class="amount off">$68.99</small>
                                    <span class="amount text-primary">$59.99</span>
                                </div>
                                <span class="product-badge bottom left text-warning">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star-half-o"></i>
                                    <i class="fa fa-star-o"></i>
                                </span>
                            </div><!-- end caption -->
                        </div><!-- end thumbnail -->
                        
                        <div class="thumbnail store style1">
                            <div class="header">
                                <figure>
                                    <a href="shop-single-product-v1.html">
                                        <img src="img/products/women_04.jpg" alt="">
                                    </a>
                                </figure>
                            </div>
                            <div class="caption">
                                <h6 class="regular"><a href="shop-single-product-v1.html">Printed Summer Dress</a></h6>
                                <div class="price">
                                    <small class="amount off">$68.99</small>
                                    <span class="amount text-primary">$59.99</span>
                                </div>
                                <span class="product-badge bottom left text-warning">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star-half-o"></i>
                                    <i class="fa fa-star-o"></i>
                                </span>
                            </div><!-- end caption -->
                        </div><!-- end thumbnail -->
                    </div><!-- end item -->
                </div><!-- end owl carousel -->
                
                <hr class="spacer-30 no-border">
                
                <div class="row">
                    <div class="col-sm-12">
                        <h4 class="mb-20">Our brands</h4>
                    </div><!-- end col -->
                </div><!-- end row -->
                
                <div id="owl-demo" class="owl-carousel column-5 owl-theme">
                    <div class="item">
                        <figure class="zoom-out">
                            <img src="img/brands/brand_01.jpg" alt="">
                        </figure>
                    </div><!-- end item -->
                    <div class="item">
                        <figure class="zoom-out">
                            <img src="img/brands/brand_02.jpg" alt="">
                        </figure>
                    </div><!-- end item -->
                    <div class="item">
                        <figure class="zoom-out">
                            <img src="img/brands/brand_03.jpg" alt="">
                        </figure>
                    </div><!-- end item -->
                    <div class="item">
                        <figure class="zoom-out">
                            <img src="img/brands/brand_04.jpg" alt="">
                        </figure>
                    </div><!-- end item -->
                    <div class="item">
                        <figure class="zoom-out">
                            <img src="img/brands/brand_01.jpg" alt="">
                        </figure>
                    </div><!-- end item -->
                    <div class="item">
                        <figure class="zoom-out">
                            <img src="img/brands/brand_02.jpg" alt="">
                        </figure>
                    </div><!-- end item -->
                    <div class="item">
                        <figure class="zoom-out">
                            <img src="img/brands/brand_03.jpg" alt="">
                        </figure>
                    </div><!-- end item -->
                    <div class="item">
                        <figure class="zoom-out">
                            <img src="img/brands/brand_04.jpg" alt="">
                        </figure>
                    </div><!-- end item -->
                </div><!-- end owl carousel -->
                
            </div><!-- end container -->    
        </section>
        <!-- end section -->
        
             
       
 
       <!--  
       <section class="section image-background layer-white" style="background-image: url(img/coming-soon-bg.jpg);">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="title-wrap">
                            <h2 class="title">Image Background</h2>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        -->
        
       
        
        <!-- start footer -->
        <footer class="footer">
            <div class="container">
                <div class="row">
                    <div class="col-sm-3">
                        <div class="icon-boxes style1">
                            <div class="icon">
                                <i class="fa fa-truck text-gray"></i>
                            </div><!-- end icon -->
                            <div class="box-content">
                                <h6 class="alt-font text-light text-uppercase">Free Shipping</h6>
                                <p class="text-gray">Aenean semper lacus sed molestie sollicitudin.</p>
                            </div>
                        </div><!-- icon-box -->
                    </div><!-- end col -->
                    <div class="col-sm-3">
                        <div class="icon-boxes style1">
                            <div class="icon">
                                <i class="fa fa-life-ring text-gray"></i>
                            </div><!-- end icon -->
                            <div class="box-content">
                                <h6 class="alt-font text-light text-uppercase">Support 24/7</h6>
                                <p class="text-gray">Aenean semper lacus sed molestie sollicitudin.</p>
                            </div>
                        </div><!-- icon-box -->
                    </div><!-- end col -->
                    <div class="col-sm-3">
                        <div class="icon-boxes style1">
                            <div class="icon">
                                <i class="fa fa-gift text-gray"></i>
                            </div><!-- end icon -->
                            <div class="box-content">
                                <h6 class="alt-font text-light text-uppercase">Gift cards</h6>
                                <p class="text-gray">Aenean semper lacus sed molestie sollicitudin.</p>
                            </div>
                        </div><!-- icon-box -->
                    </div><!-- end col -->
                    <div class="col-sm-3">
                        <div class="icon-boxes style1">
                            <div class="icon">
                                <i class="fa fa-credit-card text-gray"></i>
                            </div><!-- end icon -->
                            <div class="box-content">
                                <h6 class="alt-font text-light text-uppercase">Payment 100% Secure</h6>
                                <p class="text-gray">Aenean semper lacus sed molestie sollicitudin.</p>
                            </div>
                        </div><!-- icon-box -->
                    </div><!-- end col -->
                </div><!-- end row -->
                
                <hr class="spacer-30">
                
                <div class="row">
                    <div class="col-sm-3">
                        <h5 class="title">Plus</h5>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin suscipit, libero a molestie consectetur, sapien elit lacinia mi.</p>
                        
                        <hr class="spacer-10 no-border">
                        
                        <ul class="social-icons">
                            <li class="facebook"><a href="javascript:void(0);"><i class="fa fa-facebook"></i></a></li>
                            <li class="twitter"><a href="javascript:void(0);"><i class="fa fa-twitter"></i></a></li>
                            <li class="dribbble"><a href="javascript:void(0);"><i class="fa fa-dribbble"></i></a></li>
                            <li class="linkedin"><a href="javascript:void(0);"><i class="fa fa-linkedin"></i></a></li>
                            <li class="youtube"><a href="javascript:void(0);"><i class="fa fa-youtube"></i></a></li>
                            <li class="behance"><a href="javascript:void(0);"><i class="fa fa-behance"></i></a></li>
                        </ul>
                    </div><!-- end col -->
                    <div class="col-sm-3">
                        <h5 class="title">My Account</h5>
                        <ul class="list alt-list">
                            <li><a href="my-account.html"><i class="fa fa-angle-right"></i>My Account</a></li>
                            <li><a href="wishlist.html"><i class="fa fa-angle-right"></i>Wishlist</a></li>
                            <li><a href="cart.html"><i class="fa fa-angle-right"></i>My Cart</a></li>
                            <li><a href="checkout.html"><i class="fa fa-angle-right"></i>Checkout</a></li>
                        </ul>
                    </div><!-- end col -->
                    <div class="col-sm-3">
                        <h5 class="title">Information</h5>
                        <ul class="list alt-list">
                            <li><a href="about-us-v1.html"><i class="fa fa-angle-right"></i>About Us</a></li>
                            <li><a href="faq.html"><i class="fa fa-angle-right"></i>FAQ</a></li>
                            <li><a href="privacy-policy.html"><i class="fa fa-angle-right"></i>Privacy Policy</a></li>
                            <li><a href="contact-v1.html"><i class="fa fa-angle-right"></i>Contact Us</a></li>
                        </ul>
                    </div><!-- end col -->
                    <div class="col-sm-3">
                        <h5 class="title">Payment Methods</h5>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                        <ul class="list list-inline">
                            <li class="text-white"><i class="fa fa-cc-visa fa-2x"></i></li>
                            <li class="text-white"><i class="fa fa-cc-paypal fa-2x"></i></li>
                            <li class="text-white"><i class="fa fa-cc-mastercard fa-2x"></i></li>
                            <li class="text-white"><i class="fa fa-cc-discover fa-2x"></i></li>
                        </ul>
                    </div><!-- end col -->
                </div><!-- end row -->
                
                <hr class="spacer-30">
                
                <div class="row text-center">
                    <div class="col-sm-12">
                        <p class="text-sm">&COPY; 2017. Made with <i class="fa fa-heart text-danger"></i> by <a href="javascript:void(0);">DiamondCreative.</a></p>
                    </div><!-- end col -->
                </div><!-- end row -->
            </div><!-- end container -->
        </footer>
        <!-- end footer -->
        
        <!-- JavaScript Files -->
        <script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <script type="text/javascript" src="js/owl.carousel.min.js"></script>
        <script type="text/javascript" src="js/jquery.downCount.js"></script>
        <script type="text/javascript" src="js/nouislider.min.js"></script>
        <script type="text/javascript" src="js/jquery.sticky.js"></script>
        <script type="text/javascript" src="js/pace.min.js"></script>
        <script type="text/javascript" src="js/star-rating.min.js"></script>
        <script type="text/javascript" src="js/wow.min.js"></script>
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>
        <script type="text/javascript" src="js/gmaps.js"></script>
        <script type="text/javascript" src="js/swiper.min.js"></script>
        <script type="text/javascript" src="js/main.js"></script>
            		  <script>
  $(document).ready(function(){
    setTimeout(function() {
    $('#suc,#fail').fadeOut('fast');
     }, 1000);
});
</script>
    </body>
</html>