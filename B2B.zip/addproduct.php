<?php
session_start();
include('Connect.php');
 $email=$_SESSION['uemail'];
?>
<?php
 $sql="SELECT * FROM users Where email='$email'";
 
$stmt=mysqli_query($connection,$sql);
if($stmt == false) {
trigger_error('Wrong SQL: ' . $sql . ' Error: ' . $connection->error, E_USER_ERROR);
}
$nr=mysqli_num_rows($stmt);    
$row=$stmt->fetch_assoc();
echo $userId=$row['user_id'];

if(isset($_POST['save']))
	{
	   /////////////////////////////
		    $title = $_POST['title'];// item name
			$price = $_POST['price'];// item name
	    	$description = $_POST['description'];// item name
			$catid = $_POST['catid'];// item name
			
			$target_dir = "images/";
	
		 		$target_file = $target_dir . basename($_FILES["file1"]["name"]);
				$image=$_FILES['file1']['name'];
			$filelocation = $target_dir.$image;
        $temp = $_FILES['file1']['tmp_name'];
		 move_uploaded_file($temp, $filelocation);

		 
		 $query="INSERT INTO products(ntitle,price,fulldescription,image,catid,user_id) VALUES ('$title','$price','$description','$image','$catid','$userId')";
			
		$result = $connection->prepare($query);
			if($result === false) {
		trigger_error('Wrong SQL: ' . $query . ' Error: ' . $conn->error, E_USER_ERROR);
	}
	
		

			if($result->execute())
			{
			?>
			  <script >;
                alert("Inserted !");  //not showing an alert box.
		       window.location.href="product.php";
         </script>
			<?php

			}
	
			else
			{
			?>
			 <script >;
                alert("Error in Insertion !");  //not showing an alert box.
		       window.location.href="product.php";
         </script>
		<?php	}
		}
	
	?>