<?php
include('header.php');
 include('Connect.php');


if(isset($_POST['save']))
	{
	   /////////////////////////////
	 echo   $title=$_POST['title'];
		  $price =$_POST['price'];
	    	$date =  date("h:i:sa");// item name
				
		 $query="INSERT INTO membership(membershiptype,date,price) VALUES ('$title','$date','$price')";
			
		$result = $connection->prepare($query);
			if($result === false) {
		trigger_error('Wrong SQL: ' . $query . ' Error: ' . $connection->error, E_USER_ERROR);
	}
	
		

			if($result->execute())
			{
			?>
			  <script >;
                alert("Inserted !");  //not showing an alert box.
		       window.location.href="seller.php";
         </script>
			<?php

			}
	
			else
			{
			?>
			 <script >;
                alert("Error in Insertion !");  //not showing an alert box.
		       window.location.href="memberhip.php";
         </script>
		<?php	}
		}
	
	
	?>
        <!-- start section -->
        <section class="section white-backgorund">
            <div class="container">
			<h2 style="padding-left:350px;">Apply For Member Ship</h2>
			</br>
			</br>
                <div class="row">
	<form method="POST" >

                    <div class="col-sm-4 col-sm-push-1"  style="border: 2px solid black">
                <h2>Price : $0 </h2>
	<input type="hidden" name="title" value="Free Membership"/>
		<input type="hidden" name="price" value="$0" />
						
			<img style="height:240px; width:355px;"src="images/free.jpg" />
				<h3>FREE MEMBERSHIP  &nbsp; <input name="save" type="submit" value="BUY NOW" class="btn btn-default"/></h3>
				 
                    </div>
					</form>
					
					<!-- end col -->  
				<form method="POST" >
				<div class="col-sm-2 col-sm-push-1"  >
                </div><!-- end col -->  
				<input type="hidden" name="title" value="Basic Membership" />
				<input type="hidden" name="price" value="$100" />
                    <div class="col-sm-4 col-sm-push-1"  style="border: 2px solid black">
                <h2>Price : $100 </h2>
				<img style="height:240px; width:355px;"src="images/basic.jpg" />
				<h3>BASIC MEMBERSHIP &nbsp;<input type="submit"  name="save" value="BUY NOW" class="btn btn-default"/></h3>
				</form>  
                    </div>
				
                </div><!-- end row -->
            </div><!-- end container -->
        </section>
				
        <!-- end section -->
               
        <!-- start footer -->
    