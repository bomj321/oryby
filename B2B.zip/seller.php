<?php
session_start();
include('header.php');
 include('Connect.php');
$email=$_SESSION['uemail'];
 ?>

        <!-- start section -->
        <section class="section white-backgorund">
            <div class="container">
			
			</br>
			</br>
                <div class="row">
						
                </div><!-- end row -->
            </div><!-- end container -->
        </section>
					
        <!-- end section -->
               
        <!-- start footer -->
    