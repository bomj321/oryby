  <?php       
session_start(); 
require("Connect.php");
if(isset($_POST['save']))
{
 $email=$_POST["email"];
 $password=$_POST["password"];

 
 $sql="SELECT * FROM users WHERE email= '$email' AND password='$password'";
$stmt=mysqli_query($connection,$sql);
if($stmt == false) {
trigger_error('Wrong SQL: ' . $sql . ' Error: ' . $connection->error, E_USER_ERROR);
}


 $nr = mysqli_num_rows($stmt);

if($nr)
{



  while($row = mysqli_fetch_array($stmt))
   {

     $email=$row['email'];
	 $password = $row['password'];// item name
	 $type =$row['userType'];
	 if($type =="Admin")
	 {
	
	 ?>
	 <script>
		
				window.location.href='index.php';
				</script>
	<?php }
	
	 }
	 }
	 else
	 {
	 ?>
	  <script>
		         alert("Incorrect Password or Email");
				window.location.href='login.php';
				</script><?php
				
	 }
	} 
    	 
 
 ?>