<?php
session_start();
include('Connect.php');

if(isset($_POST['save']))
	{
	   /////////////////////////////
		    $title = $_POST['title'];// item name
			 $catid = $_POST['catid'];// item name
		
				 
		 $query="INSERT INTO subcategories(subtitle,catid) VALUES ('$title','$catid')";
			
		$result = $connection->prepare($query);
			if($result === false) {
		trigger_error('Wrong SQL: ' . $query . ' Error: ' . $connection->error, E_USER_ERROR);
	}
	
		

			if($result->execute())
			{
			?>
			  <script >;
                alert("Inserted !");  //not showing an alert box.
		       window.location.href="managesubcategories.php";
         </script>
			<?php

			}
	
			else
			{
			?>
			 <script >;
                alert("Error in Insertion !");  //not showing an alert box.
		       window.location.href="managesubcategories.php";
         </script>
		<?php	}
		}
	
	?>