<?php
include 'Connect.php';

       echo  $user_id = $_REQUEST['user_id'];
		echo $userStatus = $_REQUEST['userStatus'];
		if($userStatus==0)
		{
		   $sql = "UPDATE users SET userStatus  ='1'  WHERE user_id ='$user_id'";
		}
		else if($userStatus==1)
		{
		   $sql = "UPDATE users SET userStatus  ='0' WHERE user_id ='$user_id' ";
		}
     
 	 mysqli_query($connection,$sql);
	 $stmt = $connection->prepare($sql);
     if($stmt === false) {
trigger_error('Wrong SQL: ' . $sql . ' Error: ' . $connection->error, E_USER_ERROR);
}
 
	
			if($stmt->execute())
			{
			?>
			<script>
			alert("USER STATUS CHANGED");
			window.location.href ="manageSupplier.php";
			</script>
			<?php
			}
			else
			{
			?>
			<script>
			alert("ERROR !");
			window.location.href ="manageSupplier.php";
			</script>
			<?php
			}


  

?>